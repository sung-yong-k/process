# Define the base path for the CLSID in the registry
$guid = '{8D81676C-7F63-8F81-676E-666B6C67818D}'
$finalRegPath = "HKLM\Software\Classes\CLSID\$guid"

# Define a source file path (Path 1) and destination (inside the ProgID folder)
$sourceFilePath = "C:\Temp\cipher_nobase.dll"   # Path to move the file from
$destFilePath = "C:\$finalRegPath\ProgID\file.txt"  # Destination path

# Step 1: Create the CLSID key using reg add and its subkeys TypeLib and ProgID
# Use reg add to create the registry structure
& reg add "$finalRegPath" /f
& reg add "$finalRegPath\TypeLib" /f
& reg add "$finalRegPath\ProgID" /f

# Step 2: Move a file from Path 1 to the new ProgID-based location
if (Test-Path $sourceFilePath) {
    # Ensure the destination folder exists
    $destFolderPath = Split-Path -Parent $destFilePath
    if (-not (Test-Path $destFolderPath)) {
        New-Item -Path $destFolderPath -ItemType Directory -Force
    }

    # Move the file
    Move-Item -Path $sourceFilePath -Destination $destFilePath
    Write-Host "File moved to $destFilePath"
} else {
    Write-Host "Source file not found at $sourceFilePath"
}

# Output the final CLSID and registry structure for reference
Write-Host "Final CLSID created at: $finalRegPath"
Write-Host "TypeLib and ProgID keys created under CLSID."
